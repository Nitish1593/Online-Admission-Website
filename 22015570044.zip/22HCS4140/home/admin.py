from django.contrib import admin
from home.models import Contact, Destination

admin.site.register(Contact)
admin.site.register(Destination)
